﻿namespace CEB.Inventarios {
    
    
    public partial class dsProductosVentas {
    }
}

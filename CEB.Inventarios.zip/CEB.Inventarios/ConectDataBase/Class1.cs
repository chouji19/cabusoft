﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConectDataBase
{
    public class Class1
    {
    }
}

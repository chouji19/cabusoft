drop table [dbo].[tblCompras]
drop table [dbo].[tblMovimientoProductos]
drop table [dbo].[tblLogs]
drop table [dbo].[tblMovimientos]
drop table [dbo].[tblVentas]
drop table [dbo].[tblProductos]
drop table [dbo].[tblSubCategorias]
drop table [dbo].[tblCategorias]
drop table [dbo].[tblEstadosProductos]
drop table [dbo].[tblFacturas]
drop table [dbo].[tblUsuarios]
drop table [dbo].[tblRoles]
drop table [dbo].[tblSucursales]
drop table [dbo].[tblEmpresa]






﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CABU.Data.Utils
{
    public class Constantes
    {
        private static string Cedula = "1";
        private static string Nit = "2";
        private static string CedulaExtranjeria = "3";
        private static string Pasaporte = "4";
    }
}
